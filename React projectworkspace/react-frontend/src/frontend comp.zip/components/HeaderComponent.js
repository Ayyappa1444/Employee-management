import React from 'react'

function HeaderComponent() {
  return (
    <div>
                <header >

                    <div className='navbar navbar-expand-lg navbar-dark bg-dark'>
                        <div className='container'>
                        <a href='' className='navbar-brand'> Employee Management System</a>
                        </div>                            
                    </div>

                </header>
    </div>
  )
}

export default HeaderComponent
