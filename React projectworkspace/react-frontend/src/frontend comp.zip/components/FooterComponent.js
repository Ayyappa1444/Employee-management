
import React from 'react'
import  '../App.css';

function FooterComponent() {
  return (
    <div>
          <footer className='footer'>
            <span>All Right Reserved 2024 &copy;SWATHI </span>
          </footer>
    </div>
  )
}

export default FooterComponent
